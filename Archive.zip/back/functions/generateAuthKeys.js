module.exports = {
    name: "generateAuthKeys",
    params: [{
        name: "type", // enum
        description: "Type",
        required: true
    },
    {
        name: "userAgent", // string
        description: "Spoof Client",
        required: true
    },
    {
        name: "successlog",
        description: "Show successful on console",
        required: true
    }],
    code: `
    $let[agent;$if[$or[$env[userAgent]==;$env[userAgent]==null];Mozilla/5.0 (Windows NT 10.0\\; Win64\\; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36;$env[userAgent]]]
    $let[typedebug;$callFunction[configMusic;debug_auth]]

    $if[$or[$env[type]==all;$env[type]==youtube];
    $try[
        $httpAddHeader[User-Agent;$get[agent]]
        $httpAddHeader[Accept-Encoding;gzip]
        $httpSetContentType[Text]
        $!httpRequest[https://www.youtube.com/embed;GET;g3]
        $let[a3;$advancedTextSplit[$env[g3];"INNERTUBE_API_KEY":";1;";0]]
        $let[a32;$advancedTextSplit[$env[g3];"visitorData":";1;";0]]
        $if[$get[a3]!=;$!setGlobalVar[authmusic_youtube_key;$get[a3]]]
        $if[$get[a32]!=;$!setGlobalVar[authmusic_youtube_visitor;$get[a32]]]
        $if[$env[successlog]==true;$logger[Info;$if[$get[a3]!=;$cropText[$get[a3];0;12;...];Failed to Retrieve] | Youtube / Key]]
        $if[$env[successlog]==true;$logger[Info;$if[$get[a32]!=;$cropText[$get[a32];0;12;...];Failed to Retrieve] | Youtube / Visitor]]
    ;$logger[Error;Failed to Retrieve - Youtube]]
    $if[$get[typedebug];$chalkLog[\\[PLAYER\\] Generating Youtube | Key & Visitor;cyan]]
    ]
    $if[$or[$env[type]==all;$env[type]==soundcloud];
    $try[
        $httpAddHeader[User-Agent;$get[agent]]
        $httpAddHeader[Accept-Encoding;gzip]
        $!httpRequest[https://w.soundcloud.com/player/;GET]
        $arrayLoad[storeclientid]
        $arrayLoad[conres;widget.sndcdn.com;$httpResult]
        $arrayMap[conres;conrest;$if[$checkContains[$env[conrest];.js];$return[https://widget.sndcdn.com$advancedTextSplit[$env[conrest];</script>;0;";0]]];conres2]
        $arrayForEach[conres2;conres3;
        $try[$!httpRequest[$env[conres3];GET]]
        $if[$charCount[$advancedTextSplit[$httpResult;location.search;1;AlwaysAllowSeekStrategy;0;client_id;1;";1]]==32;
        $arrayPushJSON[storeclientid;$advancedTextSplit[$httpResult;location.search;1;AlwaysAllowSeekStrategy;0;client_id;1;";1]]
        $arrayPushJSON[storeclientid;$advancedTextSplit[$httpResult;location.search;1;AlwaysAllowSeekStrategy;0;client_id;1;";3]]
        ]]
    $if[$env[storeclientid;0]!=;$!setGlobalVar[authmusic_soundcloud;$env[storeclientid;0]]]
    $if[$env[storeclientid;1]!=;$!setGlobalVar[authmusic_soundcloud_fall;$env[storeclientid;1]]]
    $if[$env[successlog]==true;$logger[Info;$if[$env[storeclientid;0]!=;$cropText[$env[storeclientid;0];0;12;...];Failed to Retrieve] | Soundcloud / Player]]
    $if[$env[successlog]==true;$logger[Info;$if[$env[storeclientid;1]!=;$cropText[$env[storeclientid;1];0;12;...];Failed to Retrieve] | Soundcloud / Stream]]
    ;$logger[Error;Failed to Retrieve - Soundcloud]]
    $if[$get[typedebug];$chalkLog[\\[PLAYER\\] Generating Soundcloud          | ClientID;cyan]]
    ]
    $if[$or[$env[type]==all;$env[type]==spotify];
    $try[
        $httpAddHeader[User-Agent;$get[agent]]
        $httpSetBody[{"client_data":{"client_version":"5.0","client_id":"d8a5ed958d274c2e8ee717e6a4b0971d","js_sdk_data":{}}}]
        $httpAddHeader[Accept;application/json]
        $httpAddHeader[Content-type;application/json]
        $httpAddHeader[Accept-Encoding;gzip]
        $httpAddHeader[Origin;https://open.spotify.com/]
        $!httpRequest[https://clienttoken.spotify.com/v1/clienttoken;POST]
        $if[$httpResult[granted_token]!=;$!setGlobalVar[authmusic_spotify_token;$httpResult[granted_token;token]]]
        $if[$env[successlog]==true;$logger[Info;$if[$httpResult[granted_token;token]!=;$cropText[$httpResult[granted_token;token];0;12;...];Failed to Retrieve] | Spotify / Token]]
        $httpAddHeader[User-Agent;$get[agent]]
        $httpAddHeader[Accept-Encoding;gzip]
        $httpSetContentType[Text]
        $!httpRequest[https://open.spotify.com/embed/track/$randomText[4PTG3Z6ehGkBFwjybzWkR8;2yR2sziCF4WEs3klW1F38d;0IuVhCflrQPMGRrOyoY5RW;2yWlGEgEfPot0lv3OAjuG3;4Xfp9BcKrKYmxJPxn68Yb8;7uuJqaRjSXzja6VGgDpWem;3BP1klbHxsOf6IxscNIX0r;6BYzwbWg1Z2EB6VUXTYnhm];GET]
        $let[token;$advancedTextSplit[$httpResult;"accessToken":";1;";0]]
        $if[$get[token]!=;$!setGlobalVar[authmusic_spotify;$get[token]]]
        $if[$env[successlog]==true;$logger[Info;$if[$get[token]!=;$cropText[$get[token];0;12;...];Failed to Retrieve] | Spotify / Key]]
    ;$logger[Error;Failed to Retrieve - Spotify]]
    $if[$get[typedebug];$chalkLog[\\[PLAYER\\] Generating Spotify             | Key;cyan]]
    $if[$get[typedebug];$chalkLog[\\[PLAYER\\] Generating Spotify             | Token;cyan]]
    ]
    $if[$or[$env[type]==all;$env[type]==amazonmusic];
    $try[
        $httpAddHeader[Origin;https://music.amazon.com/]
        $httpAddHeader[User-Agent;$get[agent]]
        $httpAddHeader[Accept-Encoding;gzip]
        $!httpRequest[https://music.amazon.com/config.json;GET;tokens]
        $if[$env[tokens;csrf;token]!=;$!setGlobalVar[authmusic_amazonmusic;$deflate[$env[tokens];base64]]]
        $if[$env[successlog]==true;$logger[Info;$if[$env[tokens;csrf;token]!=;$cropText[$env[tokens;csrf;token];0;12;...];Failed to Retrieve] | Amazon Music]]
    ;$logger[Error;Failed to Retrieve - Amazon Music]]
    $if[$get[typedebug];$chalkLog[\\[PLAYER\\] Generating Amazon Music        | Config & Token;cyan]]
    ]
    $if[$or[$env[type]==all;$env[type]==deezer];
    $try[
        $httpAddHeader[User-Agent;$get[agent]]
        $httpAddHeader[Origin;https://www.deezer.com]
        $httpAddHeader[Accept-Encoding;gzip]
        $httpSetContentType[Text]
        $!httpRequest[https://auth.deezer.com/login/anonymous?jo=p;GET;dee]
        $jsonLoad[zer;$env[dee]]
        $if[$env[zer;jwt]!=;$!setGlobalVar[authmusic_deezer;$env[zer;jwt]]]
        $if[$env[successlog]==true;$logger[Info;$if[$env[zer;jwt]!=;$cropText[$env[zer;jwt];0;12;...];Failed to Retrieve] | Deezer]]
    ;$logger[Error;Failed to Retrieve - Deezer]]
    $if[$get[typedebug];$chalkLog[\\[PLAYER\\] Generating Deezer              | Token;cyan]]
    ]
    $if[$or[$env[type]==all;$env[type]==tiktok];
    $try[
        $httpAddHeader[User-Agent;$get[agent]]
        $httpAddHeader[Accept-Encoding;gzip]
        $httpSetContentType[Text]
        $!httpRequest[https://m.tiktok.com/;GET]
        $let[a13;$httpGetHeader[Set-Cookie]]
        $let[a12;$advancedTextSplit[$httpResult;"webapp.app-context";1;"odinId":";1;";0]]
        $if[$get[a13]!=;$!setGlobalVar[authmusic_tiktok;$deflate[$get[a13];base64]]]
        $if[$get[a12]!=;$!setGlobalVar[authmusic_tiktok_did;$get[a12]]]
        $if[$env[successlog]==true;$logger[Info;$if[$get[a13]!=;$cropText[$deflate[$get[a13];base64];0;12;...];Failed to Retrieve] | Tiktok / Cookie]]
        $if[$env[successlog]==true;$logger[Info;$if[$get[a12]!=;$cropText[$get[a12];0;12;...];Failed to Retrieve] | Tiktok / Device ID]]
    ;$logger[Error;Failed to Retrieve - Tiktok]]
    $if[$get[typedebug];$chalkLog[\\[SEARCH\\] Generating Tiktok              | Token;cyan]]
    ]
    $if[$or[$env[type]==all;$env[type]==applemusic];
    $try[
        $httpAddHeader[User-Agent;$get[agent]]
        $httpAddHeader[Accept-Encoding;gzip]
        $!httpRequest[https://embed.music.apple.com/build/web-embed.esm.js;GET]
        $!httpRequest[https://embed.music.apple.com/build/$advancedTextSplit[$httpResult;embed-empty-state;1;embed-;0;";2].entry.js;GET;a14s]
        $let[a14;$advancedTextSplit[$env[a14s];Ye=";1;";0]]
        $if[$get[a14]!=;$!setGlobalVar[authmusic_applemusic;$get[a14]]]
        $if[$env[successlog]==true;$logger[Info;$if[$get[a14]!=;$cropText[$get[a14];0;12;...];Failed to Retrieve] | Apple Music]]
    ;$logger[Error;Failed to Retrieve - Apple Music]]
    $if[$get[typedebug];$chalkLog[\\[SEARCH\\] Generating Apple Music         | Token;cyan]]
    ]
    $return
    `
}